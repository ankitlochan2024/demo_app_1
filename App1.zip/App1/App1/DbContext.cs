﻿namespace App1
{
    public class DbContext
    {
    }
}